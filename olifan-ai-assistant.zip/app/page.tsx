"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Mic, MicOff, Send, Volume2, VolumeX, Loader2 } from "lucide-react"
import Image from "next/image"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export default function Page() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm your Olifan AI Assistant. I specialize in AI solutions, agentic AI, digital transformation, and innovation consulting. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Initialize Speech Recognition
  useEffect(() => {
    if (typeof window !== "undefined" && ("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = "en-US"

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        setInput(transcript)
        setIsRecording(false)
      }

      recognitionRef.current.onerror = () => {
        setIsRecording(false)
      }

      recognitionRef.current.onend = () => {
        setIsRecording(false)
      }
    }
  }, [])

  // Handle sending messages
  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // TODO: Replace this with your actual LLM API call
    // Example with OpenAI:
    // const response = await fetch('/api/chat', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ messages: [...messages, userMessage] }),
    // })
    // const data = await response.json()

    // Simulated AI response (replace with actual API call)
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: generateMockResponse(userMessage.content),
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsLoading(false)
    }, 1500)
  }

  // Mock AI response generator (replace with actual LLM)
  const generateMockResponse = (userInput: string): string => {
    const lowerInput = userInput.toLowerCase()

    if (lowerInput.includes("ai") || lowerInput.includes("artificial intelligence")) {
      return "At Olifan Group, we specialize in implementing cutting-edge AI solutions. Our expertise covers agentic AI systems, machine learning, and intelligent automation. We help organizations leverage AI to transform their operations and create competitive advantages. What specific AI challenge are you looking to address?"
    }

    if (lowerInput.includes("digital transformation") || lowerInput.includes("transform")) {
      return "Digital transformation is at the core of what we do. We guide businesses through their entire transformation journey—from strategy development to implementation and optimization. Our approach ensures sustainable change that drives real business value. Would you like to discuss your organization's transformation roadmap?"
    }

    if (lowerInput.includes("consult") || lowerInput.includes("help")) {
      return "We provide comprehensive consulting services across AI strategy, implementation, and optimization. Our team brings deep expertise in emerging technologies and proven methodologies. We work closely with your organization to ensure successful outcomes. What area would you like to explore further?"
    }

    if (lowerInput.includes("innovation")) {
      return "Innovation is the driving force behind everything we do. We help organizations foster innovation cultures, implement innovative technologies, and stay ahead of market disruptions. Our approach combines strategic thinking with practical execution. How can we help accelerate innovation in your organization?"
    }

    return "Thank you for your question. At Olifan Group, we're committed to delivering excellence in AI solutions, digital transformation, and innovation consulting. Our team of experts is ready to help you navigate the complexities of modern technology and achieve your strategic objectives. Could you provide more details about your specific needs?"
  }

  // Handle voice recording
  const toggleRecording = () => {
    if (!recognitionRef.current) {
      alert("Speech recognition is not supported in your browser.")
      return
    }

    if (isRecording) {
      recognitionRef.current.stop()
      setIsRecording(false)
    } else {
      recognitionRef.current.start()
      setIsRecording(true)
    }
  }

  // Handle text-to-speech
  const speakMessage = (text: string) => {
    if (typeof window === "undefined") return

    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
      return
    }

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.volume = 1

    utterance.onend = () => {
      setIsSpeaking(false)
    }

    window.speechSynthesis.speak(utterance)
    setIsSpeaking(true)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-3 py-3 sm:px-4 sm:py-4 md:py-6">
          <div className="flex flex-col items-center gap-2 sm:gap-3">
            <Image
              src="/olifan-logo.png"
              alt="Olifan Group"
              width={180}
              height={60}
              className="h-8 sm:h-10 md:h-12 w-auto"
              priority
            />
            <p className="text-xs sm:text-sm md:text-base text-muted-foreground text-center text-balance px-2">
              Leader français dans la gestion de patrimoine
            </p>
          </div>
        </div>
      </header>

      {/* Main Chat Interface */}
      <main className="container mx-auto px-3 sm:px-4 py-4 sm:py-6 md:py-8 max-w-4xl flex-1 flex flex-col">
        <Card className="shadow-lg border-border/40 flex-1 flex flex-col">
          <div className="flex flex-col h-full sm:h-[500px] md:h-[700px]">
            {/* Messages Container */}
            <div className="flex-1 overflow-y-auto p-3 sm:p-4 md:p-6 space-y-3 sm:space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[90%] sm:max-w-[85%] md:max-w-[75%] rounded-2xl px-3 py-2 sm:px-4 sm:py-3 ${
                      message.role === "user"
                        ? "bg-primary text-primary-foreground ml-auto"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <p className="text-sm sm:text-base leading-relaxed whitespace-pre-wrap">{message.content}</p>
                    {message.role === "assistant" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="mt-2 h-7 px-2 text-xs hover:bg-background/10"
                        onClick={() => speakMessage(message.content)}
                      >
                        {isSpeaking ? (
                          <>
                            <VolumeX className="h-3 w-3 mr-1" />
                            Stop
                          </>
                        ) : (
                          <>
                            <Volume2 className="h-3 w-3 mr-1" />
                            Listen
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </div>
              ))}

              {/* Loading Indicator */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-muted text-foreground max-w-[90%] sm:max-w-[85%] md:max-w-[75%] rounded-2xl px-3 py-2 sm:px-4 sm:py-3">
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin text-primary" />
                      <span className="text-sm text-muted-foreground">Thinking...</span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-border p-3 sm:p-4 md:p-6 bg-card/50">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
                    placeholder="Type your message..."
                    className="pr-11 h-11 sm:h-12 text-sm sm:text-base"
                    disabled={isLoading}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`absolute right-1 top-1 h-9 w-9 sm:h-10 sm:w-10 ${isRecording ? "text-primary" : ""}`}
                    onClick={toggleRecording}
                    disabled={isLoading}
                  >
                    {isRecording ? (
                      <MicOff className="h-4 w-4 sm:h-5 sm:w-5 animate-pulse" />
                    ) : (
                      <Mic className="h-4 w-4 sm:h-5 sm:w-5" />
                    )}
                  </Button>
                </div>
                <Button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  size="icon"
                  className="h-11 w-11 sm:h-12 sm:w-12"
                >
                  <Send className="h-4 w-4 sm:h-5 sm:w-5" />
                </Button>
              </div>
              {isRecording && (
                <p className="text-xs text-muted-foreground mt-2 text-center animate-pulse">Listening... Speak now</p>
              )}
            </div>
          </div>
        </Card>

        <div className="mt-4 sm:mt-6 flex flex-wrap justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("Tell me about ingénierie patrimoniale")}
            disabled={isLoading}
            className="text-xs h-8"
          >
            Ingénierie Patrimoniale
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("How can you help with investissement financier?")}
            disabled={isLoading}
            className="text-xs h-8"
          >
            Investissement Financier
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInput("What services do you offer for retraite?")}
            disabled={isLoading}
            className="text-xs h-8"
          >
            Prévoyance et Retraite
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto py-4 sm:py-6 bg-card/30">
        <div className="container mx-auto px-3 sm:px-4">
          <p className="text-center text-xs sm:text-sm text-muted-foreground px-2">
            © {new Date().getFullYear()} Olifan Group – Leader français dans la gestion de patrimoine
          </p>
        </div>
      </footer>
    </div>
  )
}
